/* MindZZ service worker. Шинэчлэх бүрт VERSION-ийг нэгээр нэмнэ. */
const VERSION = "mindzz-v4-8";
const CORE = ["./", "./index.html", "./manifest.webmanifest", "./icons/icon-192.png", "./icons/icon-512.png",
  "./icons/icon-maskable-512.png", "./icons/apple-touch-icon.png", "./icons/favicon-32.png",
  "./fonts/lora-cyrillic-ext-wght-normal.woff2", "./fonts/lora-cyrillic-wght-normal.woff2", "./fonts/lora-latin-ext-wght-normal.woff2", "./fonts/lora-latin-wght-normal.woff2", "./fonts/manrope-cyrillic-ext-wght-normal.woff2", "./fonts/manrope-cyrillic-wght-normal.woff2", "./fonts/manrope-latin-ext-wght-normal.woff2", "./fonts/manrope-latin-wght-normal.woff2"];
self.addEventListener("install", e => { e.waitUntil(caches.open(VERSION).then(c => c.addAll(CORE)).then(() => self.skipWaiting())); });
self.addEventListener("activate", e => {
  e.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== VERSION).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener("fetch", e => {
  const req = e.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);
  if (req.mode === "navigate") {   /* хуудас: эхлээд сүлжээ, тасарвал хадгалсан хувилбар */
    e.respondWith(fetch(req).then(r => { const c = r.clone(); caches.open(VERSION).then(x => x.put("./index.html", c)); return r; })
      .catch(() => caches.match("./index.html")));
    return;
  }
  if (url.origin === location.origin) {   /* өөрийн файл: эхлээд хадгалсан */
    e.respondWith(caches.match(req).then(hit => hit || fetch(req).then(r => { const c = r.clone(); caches.open(VERSION).then(x => x.put(req, c)); return r; })));
  }
});
